# Student Management System

A beginner-friendly Student Management System built with **HTML, CSS, JavaScript, and Supabase**.

## Features
- Add student records
- View all students
- Search by name, email, or department
- Edit student details
- Delete student records
- Responsive layout

## Requirements
- A Supabase account
- A modern browser
- VS Code (recommended)

## Setup

### 1. Create the database table
1. Open your Supabase project.
2. Go to **SQL Editor**.
3. Run the SQL in [`schema.sql`](schema.sql).

### 2. Add your Supabase credentials
1. In Supabase, open **Project Settings → API** (or **Connect**, depending on the dashboard).
2. Copy the project URL and publishable/anon key.
3. Open `app.js` and replace the two placeholder values:

```js
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
```

Use only the browser-safe publishable/anon key. **Never put a `service_role` or secret key in frontend code.**

### 3. Run the app
Open `index.html` in your browser, or use the **Live Server** extension in VS Code.

## Database table
The SQL creates a `students` table with:
- `id`
- `full_name`
- `email`
- `department`
- `year`
- `created_at`

## Security note
This is a learning/demo project. The SQL enables Row Level Security (RLS) and adds a simple public policy so the app works without sign-in. That policy allows anyone with your project URL and public key to read, add, update, and delete student records. **Do not use this policy for real student or personal data.** For real use, implement Supabase Auth and restrict access to authorized users.

## Suggested GitHub repository description
`A simple Student Management System with HTML, CSS, JavaScript, and Supabase CRUD operations.`

## License
For educational use.
