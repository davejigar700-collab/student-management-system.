// Configure these with your own Supabase project details.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";

const form = document.querySelector("#student-form");
const idInput = document.querySelector("#student-id");
const nameInput = document.querySelector("#full-name");
const emailInput = document.querySelector("#email");
const departmentInput = document.querySelector("#department");
const yearInput = document.querySelector("#year");
const saveButton = document.querySelector("#save-button");
const cancelEditButton = document.querySelector("#cancel-edit");
const formHeading = document.querySelector("#form-heading");
const formMessage = document.querySelector("#form-message");
const pageMessage = document.querySelector("#page-message");
const searchInput = document.querySelector("#search");
const tableBody = document.querySelector("#students-table");
const studentCount = document.querySelector("#student-count");

let supabaseClient = null;
let students = [];

function setMessage(element, message = "", type = "") {
  element.textContent = message;
  element.className = `message ${type}`.trim();
}

function isConfigured() {
  return SUPABASE_URL.startsWith("https://")
    && !SUPABASE_URL.includes("YOUR_SUPABASE")
    && SUPABASE_ANON_KEY.length > 20
    && !SUPABASE_ANON_KEY.includes("YOUR_SUPABASE");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[character]);
}

function resetForm() {
  form.reset();
  idInput.value = "";
  formHeading.textContent = "Add a student";
  saveButton.textContent = "Add student";
  cancelEditButton.classList.add("hidden");
  setMessage(formMessage);
}

function showStudents() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = students.filter((student) =>
    [student.full_name, student.email, student.department, String(student.year)]
      .some((value) => String(value ?? "").toLowerCase().includes(query))
  );

  studentCount.textContent = String(students.length);

  if (filtered.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="5" class="empty">${
      query ? "No matching students found." : "No student records yet. Add your first student above."
    }</td></tr>`;
    return;
  }

  tableBody.innerHTML = filtered.map((student) => `
    <tr>
      <td><span class="student-name">${escapeHtml(student.full_name)}</span></td>
      <td>${escapeHtml(student.email)}</td>
      <td>${escapeHtml(student.department)}</td>
      <td>${escapeHtml(student.year)}</td>
      <td>
        <div class="actions">
          <button class="button edit" type="button" data-action="edit" data-id="${student.id}">Edit</button>
          <button class="button danger" type="button" data-action="delete" data-id="${student.id}">Delete</button>
        </div>
      </td>
    </tr>
  `).join("");
}

async function loadStudents() {
  setMessage(pageMessage, "Loading student records…");
  const { data, error } = await supabaseClient
    .from("students")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    setMessage(pageMessage, `Could not load students: ${error.message}`, "error");
    tableBody.innerHTML = `<tr><td colspan="5" class="empty">Check your Supabase URL, key, table, and RLS policies.</td></tr>`;
    return;
  }

  students = data ?? [];
  setMessage(pageMessage);
  showStudents();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!supabaseClient) return;

  const record = {
    full_name: nameInput.value.trim(),
    email: emailInput.value.trim(),
    department: departmentInput.value,
    year: Number(yearInput.value)
  };

  saveButton.disabled = true;
  setMessage(formMessage, idInput.value ? "Updating student…" : "Adding student…");

  let result;
  if (idInput.value) {
    result = await supabaseClient.from("students").update(record).eq("id", Number(idInput.value));
  } else {
    result = await supabaseClient.from("students").insert(record);
  }

  saveButton.disabled = false;

  if (result.error) {
    setMessage(formMessage, result.error.code === "23505"
      ? "This email address is already registered."
      : `Could not save student: ${result.error.message}`, "error");
    return;
  }

  setMessage(formMessage, "Student saved successfully.", "success");
  resetForm();
  await loadStudents();
});

cancelEditButton.addEventListener("click", resetForm);
searchInput.addEventListener("input", showStudents);

tableBody.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button || !supabaseClient) return;

  const id = Number(button.dataset.id);
  const student = students.find((item) => Number(item.id) === id);
  if (!student) return;

  if (button.dataset.action === "edit") {
    idInput.value = student.id;
    nameInput.value = student.full_name;
    emailInput.value = student.email;
    departmentInput.value = student.department;
    yearInput.value = String(student.year);
    formHeading.textContent = "Edit student";
    saveButton.textContent = "Save changes";
    cancelEditButton.classList.remove("hidden");
    setMessage(formMessage, `Editing ${student.full_name}.`);
    form.scrollIntoView({ behavior: "smooth", block: "start" });
    nameInput.focus();
    return;
  }

  if (button.dataset.action === "delete") {
    if (!window.confirm(`Delete the record for ${student.full_name}? This cannot be undone.`)) return;
    button.disabled = true;
    const { error } = await supabaseClient.from("students").delete().eq("id", id);
    if (error) {
      setMessage(pageMessage, `Could not delete student: ${error.message}`, "error");
      button.disabled = false;
      return;
    }
    setMessage(pageMessage, "Student deleted successfully.", "success");
    await loadStudents();
  }
});

if (!isConfigured()) {
  setMessage(pageMessage, "Setup required: add your Supabase project URL and public key in app.js.", "error");
  studentCount.textContent = "0";
  tableBody.innerHTML = `<tr><td colspan="5" class="empty">Connect your Supabase project to load records.</td></tr>`;
} else if (!window.supabase) {
  setMessage(pageMessage, "Supabase library did not load. Check your internet connection.", "error");
} else {
  supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  loadStudents();
}
